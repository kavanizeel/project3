import random
import string

def generate_dummy_key(length=5):
    """Generates a random string of fixed length."""
    return ''.join(random.choices(string.ascii_lowercase, k=length))

def generate_dummy_value():
    """Generates a random integer value between 1 and 100."""
    return random.randint(1, 100)

def generate_dummy_dict(n):
    """Generates a dummy dictionary with n key-value pairs."""
    dummy_dict = {}
    for _ in range(n):
        key = generate_dummy_key()
        # Ensure unique keys
        while key in dummy_dict:
            key = generate_dummy_key()
        dummy_dict[key] = generate_dummy_value()
    return dummy_dict

# 📥 User Input
try:
    num_keys = int(input("Enter number of keys to generate: "))
    if num_keys <= 0:
        print("Please enter a positive number.")
    else:
        result = generate_dummy_dict(num_keys)
        print("\nGenerated Dummy Dictionary:")
        print(result)
except ValueError:
    print("Invalid input! Please enter a valid integer.")
